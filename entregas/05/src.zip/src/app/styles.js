import { StyleSheet } from 'react-native';
import { grey, black } from '@constants/colors';

export default StyleSheet.create({
  titulo: {
    backgroundColor: grey,
    height: 30,
//    headerTintColor: black,
  },
});
