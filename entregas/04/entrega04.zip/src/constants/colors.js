export const grey = '#e1e1e1';
export const red = '#AA2B2B';
export const blue = '#428bca';
export const transparent = 'transparent';
export const white = '#fff';
export const black = '#000';
export const backgroudSelected = '#AA2B2B';
export const borderSelected = '#20232a';
